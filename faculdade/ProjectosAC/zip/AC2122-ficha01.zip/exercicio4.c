#include <stdio.h>
#include <limits.h>

int main() {

  printf("char: size = %zu Bytes. \n", sizeof(char));
  printf("short: size = %zu Bytes. Range = %d .. %d\n", sizeof(short), SHRT_MIN, SHRT_MAX);
  printf("int: size = %zu Bytes. Range = %d .. %d\n", sizeof(int), INT_MIN, INT_MAX);
 
  // completar

  
  return 0;
}