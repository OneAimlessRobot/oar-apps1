
#include <stdio.h>

void binoper(int x) {

  printf("\nb = %d %x\n", x, x);
  int resultado = x; // completar
  printf("a) %d  %x\n", resultado, resultado);

  resultado = x; // completar
  printf("b) %d  %x\n", resultado, resultado);

  resultado = x; // completar
  printf("c) %d  %x\n", resultado, resultado);
}

int main() {

  int x;

  printf ("Indique o número a testar:\n");
  scanf("%d", &x);
  binoper(x);
  return 0;
}

