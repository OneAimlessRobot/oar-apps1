package projectClasses.interfaces;

public interface OutsourcedProject extends Project{
/**
 * Returns the name of the company this project was outsourced to
 * @return
 */
	String getCompanyName();

}