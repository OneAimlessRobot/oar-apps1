package userClasses.interfaces;


public interface Manager extends User{
	//Interface created just for type safety concerns

}
