package smallerClasses;

import java.util.Comparator;

public class StringComparator implements Comparator<String> {
	

	public int compare(String a,String o) {
		return a.compareTo(o);
	}

}
