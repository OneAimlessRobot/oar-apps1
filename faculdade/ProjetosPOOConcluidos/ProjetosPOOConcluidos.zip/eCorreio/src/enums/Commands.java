package enums;

public enum Commands {
	EMAIL,
	ENVIAR,
	RECEBER,
	ENVIADAS,
	RECEBIDAS,
	ASSUNTO,
	ASSUNTOS,
	SAIR;

}
