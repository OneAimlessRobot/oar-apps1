01_in.txt (5 points)	- Commands exit and help
02_in.txt (10 points)	- Commands register and users
03_in.txt (15 points)	- Commands create and projects
04_in.txt (10 points)	- Command team
05_in.txt (10 points)	- Command artefact
06_in.txt (15 points) 	- Command revision and project 
07_in.txt (6 points) 	- Command manages
08_in.txt (6 points) 	- Command keyword
09_in.txt (6 points) 	- Command confidentiality
10_in.txt (7 points) 	- Command workaholics
11_in.txt (10 points) 	- Command common


