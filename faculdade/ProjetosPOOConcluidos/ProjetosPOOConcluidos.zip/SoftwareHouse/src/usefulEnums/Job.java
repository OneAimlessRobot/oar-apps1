package usefulEnums;

public enum Job {
	
	MANAGER,
	DEVELOPER;

}
