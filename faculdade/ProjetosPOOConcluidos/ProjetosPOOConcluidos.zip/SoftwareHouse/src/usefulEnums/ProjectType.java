package usefulEnums;

public enum ProjectType {
	INHOUSE,
	OUTSOURCED;

}
