package behaviour;

import mentalEntities.*;

public class TemperamentClass implements Temperament{
	
	public TemperamentClass() {
	}
	
	public futureFactorsListClass getFutureFactors() {
		return null;
		
		
		
	}

	@Override
	public void triggerMemory() {
		// TODO h a Auto-generated method stub
		
	}

	@Override
	public void actUpponMemory() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void estimateFuture() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actUpponFuture() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rebuildPast() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actUpponPast() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
