package behaviour;
import mentalEntities.*;

public interface Temperament {
	
	void triggerMemory();
	void actUpponMemory();
	void estimateFuture();
	void actUpponFuture();
	void rebuildPast();
	void actUpponPast();
	futureFactorsListClass getFutureFactors();
	

}
