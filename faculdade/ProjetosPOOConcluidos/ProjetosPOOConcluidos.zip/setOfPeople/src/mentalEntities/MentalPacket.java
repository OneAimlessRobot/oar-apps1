package mentalEntities;

public interface MentalPacket {
	
	void process();
	int getPacketPriority();

}
