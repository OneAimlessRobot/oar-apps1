package mentalEntities;

public class FutureFactorClass implements FutureFactor{
	
	

}
