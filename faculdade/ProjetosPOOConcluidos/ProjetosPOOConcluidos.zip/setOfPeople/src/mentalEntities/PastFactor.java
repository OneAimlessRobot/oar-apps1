package mentalEntities;

public interface PastFactor {

}
