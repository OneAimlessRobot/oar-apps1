package mentalEntities;

public interface FutureFactorsList {

}
