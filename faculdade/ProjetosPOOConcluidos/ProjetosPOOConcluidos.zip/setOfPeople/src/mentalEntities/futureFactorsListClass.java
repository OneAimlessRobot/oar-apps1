package mentalEntities;

public class futureFactorsListClass extends MentalPacketClass{

	public futureFactorsListClass(int priority) {
		super(priority);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getPacketPriority() {
		// TODO Auto-generated method stub
		return 0;
	}

}
