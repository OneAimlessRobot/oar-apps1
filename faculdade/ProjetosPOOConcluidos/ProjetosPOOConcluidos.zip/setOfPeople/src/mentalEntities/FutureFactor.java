package mentalEntities;

public interface FutureFactor{

}
