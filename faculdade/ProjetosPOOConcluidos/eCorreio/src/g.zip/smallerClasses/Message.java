package smallerClasses;

public interface Message{

	String getContents();
	
	String getDate();
	
	String getSubject();
	
	String getEmail();
}
