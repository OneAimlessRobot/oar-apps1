package auxClasses;

import java.time.LocalDate;

public class Deadline extends AbstractEvaluation {

	public Deadline(LocalDate date,String name,String courseName){
		super(date,name,courseName);
	}
	

}
