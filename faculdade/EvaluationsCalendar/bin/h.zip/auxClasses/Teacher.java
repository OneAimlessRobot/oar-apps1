package auxClasses;

public interface Teacher extends Person {
	
	int getNumberOfStudents();
}
