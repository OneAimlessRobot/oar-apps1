package auxClasses;

public class AbstractPerson implements Person {
	
	private String name;
	protected String type="";
	
	public AbstractPerson(String name) {
		this.name=name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getType() {
		return this.type;
	}
	
	public boolean equals(Object e) {
		boolean isEqual=false;
		if(this!=e) {
		}
		else if(e==null) {
		}
		else if(e instanceof AbstractPerson) {
			if(this.getName().equals(((AbstractPerson)e).getName())) {
				isEqual=true;
			}
		}
		return isEqual;
		
	}

}
