package auxClasses;

import dataStructures.*;

public class EvaluationsCalendarClass implements EvaluationsCalendar {

	private Array<Person> people,teachers,students;
	private Array<Course> cursos;
	
	public EvaluationsCalendarClass() {
		
		people=new ArrayClass<>();
		cursos=new ArrayClass<>();
		
		
		
		
	}
	@Override
	public void addTeacher(String name) {
		
		people.insertLast(new Teacher(name));
		
	}
//	@Override
//	public void addStudent(String name) {
//		
//		people.insertLast(new Teacher(name));
//		
//	}

	@Override
	public Iterator<Person> peopleIterator() {
		return people.iterator();
	}
	
	public Iterator<Course> coursesIterator(){
		return cursos.iterator();
	}
	public void assignPersonToCourse(String name,String course) {
	}
	@Override
	public void assignTeacherToCourse(String name, String course) {	
		cursos.get(cursos.searchIndexOf(new CourseClass(course))).
		addTeacher(people.get(people.searchIndexOf(new Teacher(name))));
	
		
	}
	@Override
	public void assignStudentToCourse(String name, String course) {
		cursos.get(cursos.searchIndexOf(new CourseClass(course))).
		addStudent(people.get(people.searchIndexOf(new Student(name,0))));
	}
	@Override
	public boolean hasTeacher(String name) {
		
		return false;
	}
	@Override
	public boolean hasStudent(String name) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean hasCourse(String name) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	

}
