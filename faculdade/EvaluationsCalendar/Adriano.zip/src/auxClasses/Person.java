package auxClasses;

public interface Person {
	
	
	String getName();
	
}
