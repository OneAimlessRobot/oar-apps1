package auxClasses;
import dataStructures.*;

public interface Course {

	/**
	 * Devolve um iterador só com os alunos deste curso.
	 * @return
	 */
	Iterator<Person> studentIterator();
	/**
	 * Devolve um iterador de toda a gente envolvida neste curso.
	 * @return
	 */
	Iterator<Person> personIterator();
	/**
	 * Devolve um iterador de todos os professores deste curso.
	 * @return
	 */
	Iterator<Person> teacherIterator();
	/**
	 * Devolve o nome do curso.
	 * @return
	 */
	String getName();
	/**
	 * Adiciona um professor a este curso
	 * @param teacher
	 */

	/**
	 * adiciona um professor ao curso.
	 * @param teacher
	 */
	void addTeacher(Person teacher);
	/**
	 * Adiciona um aluno ao curso.
	 * @param student
	 */
	void addStudent(Person student);
	void addPerson(Person student);
}
