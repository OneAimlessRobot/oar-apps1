package auxClasses;
import dataStructures.*;

public interface EvaluationsCalendar {
	
	void addTeacher(String name);
	
	Iterator<Person> peopleIterator();
	/**
	 * pre: hasTeacher(name) && hasCourse(course)
	 * Adiciona um Professor de nome "name" a um curso de nome "course"
	 * @param name
	 * @param course
	 */
	void assignTeacherToCourse(String name,String course);
	/**
	 *  pre: hasStudent(name) && hasCourse(course)
	 * Adiciona um estudante de nome "name" a um curso de nome "course"
	 * @param name
	 * @param course
	 */
	
	void assignStudentToCourse(String name,String course);
	
	/**
	 * Devolve true se houver um professor de nome "name". Devolve false caso contrário
	 * @return
	 */
	boolean hasTeacher(String name);
	/**
	 * Devolve true se houver um aluno de nome "name". Devolve false caso contrário.
	 * @param name
	 * @return
	 */
	
	boolean hasStudent(String name);

	/**
	 * Devolve true se houver um curso de nome "name". Devolve false caso contrário.
	 * @param name
	 * @return
	 */
	boolean hasCourse(String name);
	

}
