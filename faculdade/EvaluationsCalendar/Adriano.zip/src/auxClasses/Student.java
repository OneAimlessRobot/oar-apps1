package auxClasses;
import dataStructures.*;

public class Student extends AbstractPerson {
	
	private ArrayClass<Course> cursos;

	private int studentNo;
	public Student(String name,int studentNo) {
		super(name);
		this.type="Aluno";
		this.studentNo=studentNo;
		cursos=new ArrayClass<>();
		
		
	}
	
	public int getStudentNo() {
		return this.studentNo;
	}
}
