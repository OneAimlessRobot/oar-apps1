package auxClasses;

public class AbstractEvaluation implements Evaluation {

}
