package auxClasses;

public interface Evaluation {

}
