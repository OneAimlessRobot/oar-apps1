package auxClasses;
import dataStructures.*;

public class CourseClass implements Course {

	private Array<Person> teachers,roster,students;
	private String name;
	public CourseClass(String name) {
		
		this.name=name;
		teachers=new ArrayClass<>();
		roster= new ArrayClass<>();
		students=new ArrayClass<>();
		
	}
	public String getName() {
		return this.name;
	}
	
	@Override
	public Iterator<Person> studentIterator() {
		return students.iterator();
	}

	@Override
	public Iterator<Person> personIterator() {
		
		return roster.iterator();
	}
	@Override
	public Iterator<Person> teacherIterator() {
		
		return teachers.iterator();
	}
	
	public boolean equals(Course e) {
		boolean isEqual=false;
		if(this!=e) {
		}
		else if(e==null) {
		}
		else if(this.getName().equals(e.getName())) {
			isEqual=true;
		}
		return isEqual;
		
	}
	@Override
	public void addTeacher(Person teacher) {
		
		teachers.insertLast(teacher);
	}
	@Override
	public void addStudent(Person teacher) {
		
		students.insertLast(teacher);
	}
	@Override
	public void addPerson(Person teacher) {
		
		roster.insertLast(teacher);
	}

}
