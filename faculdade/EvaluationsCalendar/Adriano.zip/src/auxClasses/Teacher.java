package auxClasses;

public class Teacher extends AbstractPerson {
	
	public Teacher(String name) {
		super(name);
		this.type="Professor";
	}
	
	
}
