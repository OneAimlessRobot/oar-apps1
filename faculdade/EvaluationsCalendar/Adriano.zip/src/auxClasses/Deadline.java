package auxClasses;

public class Deadline extends AbstractEvaluation {

}
