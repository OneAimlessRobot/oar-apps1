package auxClasses;

public class Test extends AbstractEvaluation {

}
