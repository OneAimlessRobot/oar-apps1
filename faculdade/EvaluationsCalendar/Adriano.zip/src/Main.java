import java.util.Scanner;

public class Main {
	
	private static final String EXIT = "EXIT";
	private static final String HELP = "HELP";
	private static final String LIST_PEOPLE = "PEOPLE";
	private static final String ADD_PROF = "PROFESSOR";
	private static final String ADD_STD = "STUDENT";
	private static final String LIST_COURSES = "COURSES";
	private static final String ADD_COURSE = "COURSE";
	private static final String ROSTER = "ROSTER";
	private static final String ASSIGN_PROF = "ASSIGN";
	private static final String ENROL_STD = "ENROL";
	private static final String INTERSECTION = "INTERSECTION";
	private static final String LIST_DEADLINES = "COURSEDEADLINES";
	private static final String OWN_DEADLINES = "PERSONALDEADLINES";
	private static final String GIVE_DEADLINE = "DEADLINE";
	private static final String LIST_TESTS = "COURSETESTS";
	private static final String OWN_TESTS = "PERSONALTESTS";
	private static final String SCHEDULE = "SCHEDULE";
	private static final String SUP_PROF = "SUPERPROFESSOR";
	private static final String TOP_STRESS = "STRESSOMETER";
	
	private static final String NO_COMMAND = "Unknown command ";
	private static final String TYPE_HELP = "Type help to see available commands.";
	private static final String END = "Bye!";
	private static final String COMMANDS = "Available commands:";
	private static final String COMM_PEOPLE = "people - lists all people";
	private static final String COMM_PROF = "professor - adds a new professor";
	private static final String COMM_STD = "student - adds a new student";
	private static final String COMM_COURSES = "courses - lists all courses";
	private static final String COMM_COURSE = "course - adds a new course";
	private static final String COMM_ROSTER = "roster - lists the professors and students of a course";
	private static final String COMM_ASSIGN = "assign - adds a teacher to a course";
	private static final String COMM_ENROL = "enrol - adds students to a course";
	private static final String COMM_INTERSEC = "intersection - lists all the people involved in all the given courses";
	private static final String COMM_COURSEDEADL = "coursedeadlines - lists all deadlines in a given course";
	private static final String COMM_PERSONALDEADL = "personaldeadlines - lists all the deadlines of a given person";
	private static final String COMM_DEADLINE = "deadline - adds a new deadline";
	private static final String COMM_COURSETESTS = "coursetests - lists all tests in a given course";
	private static final String COMM_PERSONALTESTS = "personaltests - lists all tests for a given student";
	private static final String COMM_SCHEDULE = "schedule - add a new test to a course";
	private static final String COMM_SUPERPROF = "superprofessor - presents the professor with more students";
	private static final String COMM_STRESS = "stressometer - presents the students with the top N stressful sequences of evaluations";
	private static final String COMM_HELP = "help - shows the available commands";
	private static final String COMM_EXIT = "exit - terminates the execution of the program";
	private static final String DATA_EMPTY = "No people registered!";
	private static final String SUC_ADD = " added.";
	private static final String EXISTS = " already exists!";
	private static final String NUMBER_EXISTS = "There is already a student with the number";
	private static final String NO_COURSES = "No courses registered!";
	private static final String PROFS = " professors";
	private static final String STDS = " students";
	private static final String TESTS = " tests and ";
	private static final String DEADLINES = " deadlines.";
	private static final String ROSTER_PROF = "Professors:";
	private static final String ROSTER_STDS = "Students:";
	private static final String NOT_EXIST = " does not exist!";
	private static final String PROF = "Professor ";
	private static final String ASSIGNED = " assigned to ";
	private static final String COURSE = "Course ";
	private static final String ALREADY_ASSIGNED = " is already assigned to course ";
	private static final String ADDED_STUDENTS = " students added to course ";
	private static final String INADEQUATE_STDS = "Inadequate number of students!";
	private static final String STUDENT = "Student ";
	private static final String ENROLLED = " is already enrolled in course ";
	private static final String EMPTY_INTERSEC = "No professors or students to list!";
	private static final String INVALID_COURSES = "Inadequate number of courses!";
	private static final String NO_DEADLINES = "No deadlines defined for ";
	private static final String DEADLINE = "Deadline ";
	private static final String ADDED_TO = " added to ";
	private static final String NO_TESTS = "No scheduled tests for ";
	private static final String ALREADY_TEST = " already has a test named ";
	private static final String INVALID_SCHEDULE = "Cannot schedule test ";
	private static final String TIME = " at that time!";
	private static final String NO_PROFS = "There are no professors!";
	private static final String DAYS = " days ";
	private static final String EVALUATIONS = " evaluations ";
	private static final String NO_STRESSED = "There are no stressed students right now!";
	private static final String INVALID_STDS = "Invalid number of students!";
	
	public static void main(String[]args) {
		Scanner in = new Scanner(System.in);
		EvaluationsCalendar ec = new EvaluationsCalendarClass();
		String command;
		do {
			command = in.next().toUpperCase();
			executeCommand(in, ec, command);			
		} while(!command.equals(EXIT));
		in.close();
	}
	
	private static void executeCommand(Scanner in, EvaluationsCalendar ec, String command) {
		switch(command) {
			case EXIT:
				System.out.println(END);
				break;
			case HELP:
				printMenu();
				break;
			case LIST_PEOPLE:
				listPeople(ec);
				break;
			case ADD_PROF:
				addProfessor(in, ec);
				break;
			case ADD_STD:
				addStudent(in, ec);
				break;
			case LIST_COURSES:
				listCourses(ec);
				break;
			case ADD_COURSE:
				addCourse(in, ec);
				break;
			case ROSTER:
				listCoursePeople(in, ec);
				break;
			case ASSIGN_PROF:
				assignProfessor(in, ec);
				break;
			case ENROL_STD:
				enrolStudent(in, ec);
				break;
			case INTERSECTION:
				listIntersectedPeople(in, ec);
				break;
			case LIST_DEADLINES:
				listCourseDeadlines(in, ec);
				break;
			case OWN_DEADLINES:
				listPersonDeadlines(in, ec);
				break;
			case GIVE_DEADLINE:
				addDeadline(in, ec);
				break;
			case LIST_TESTS:
				listCourseTests(in, ec);
				break;
			case OWN_TESTS:
				listPersonTests(in, ec);
				break;
			case SCHEDULE:
				scheduleTest(in, ec);
				break;
			case SUP_PROF:
				printSuperprofessorName(ec);
				break;
			case TOP_STRESS:
				listMostStressedStudents(in, ec);
				break;
			default:
				System.out.println(NO_COMMAND + command + "." + " " + TYPE_HELP);
				break;			
		}
	}

	private static void printMenu() {
		System.out.println(COMMANDS);
		System.out.println(COMM_PEOPLE);
		System.out.println(COMM_PROF);
		System.out.println(COMM_STD);
		System.out.println(COMM_COURSES);
		System.out.println(COMM_COURSE);
		System.out.println(COMM_ROSTER);
		System.out.println(COMM_ASSIGN);
		System.out.println(COMM_ENROL);
		System.out.println(COMM_INTERSEC);
		System.out.println(COMM_COURSEDEADL);
		System.out.println(COMM_PERSONALDEADL);
		System.out.println(COMM_DEADLINE);
		System.out.println(COMM_COURSETESTS);
		System.out.println(COMM_PERSONALTESTS);
		System.out.println(COMM_SCHEDULE);
		System.out.println(COMM_SUPERPROF);
		System.out.println(COMM_STRESS);
		System.out.println(COMM_HELP);
		System.out.println(COMM_EXIT);
	}

	private static void listPeople(EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void addProfessor(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void addStudent(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listCourses(EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void addCourse(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listCoursePeople(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void assignProfessor(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void enrolStudent(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listIntersectedPeople(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listCourseDeadlines(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listPersonDeadlines(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void addDeadline(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listCourseTests(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listPersonTests(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void scheduleTest(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void printSuperprofessorName(EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}

	private static void listMostStressedStudents(Scanner in, EvaluationsCalendar ec) {
		// TODO Auto-generated method stub
		
	}
	
}
