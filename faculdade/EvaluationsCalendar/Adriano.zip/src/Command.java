
public enum Command {
	people,
	professor,
	student,
	courses,
	course,
	roster,
	assign,
	enrol,
	coursedeadlines,
	intersection,
	personaldeadlines,
	deadline,
	coursetests,
	personaltests,
	schedule,
	superprofessor,
	stressometer,
	help,
	exit;
}
