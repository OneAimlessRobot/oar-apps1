public class Brains {

    private static final int MAX_PLAYERS = 2;
    private static final int NO_PRIZE = 0;
    private static final int PLAYING = 1;
    private static final int KICKED = 0;
    private static final int STARTING_MERIT = 0;
    private static final int STARTING_POINT = -1;
    private static final int FIRST_SLOT_OF_TERRAIN = 1;

    private static Arqueologo[] players = new Arqueologo[MAX_PLAYERS];
    private int currentSlot;
    private int availableSpace;
    private Slot[] terreno;

    /*
     * Esta é a classe com a qual a main vai comunicar. Só e somente com esta. E
     * esta comunica com o resto.
     */

    public Brains(String nome1, String nome2, int terrainSize) {
        players[0] = new Arqueologo(nome1,STARTING_MERIT,0);
        players[1] = new Arqueologo(nome2,STARTING_MERIT,0);
        availableSpace = terrainSize+1;
        terreno = new Slot[availableSpace];
        terreno[currentSlot]=new Slot(NO_PRIZE);
        terreno[currentSlot].setSlotStatus(STARTING_POINT);
        currentSlot++;

    }
    /* Este método é só para teste e vai devolver o nome do arqueologo */

    public String getNameRemote(int target) {

        return players[target - 1].getPlayerName();

    }

    public int getMeritRemote(int target) {

        return players[target - 1].getPlayerMerit();

    }

    /*
     * Com este metodo, quero adicionar treasures em sequência a um determinado
     * Terrain sem ter mmethods na classe terrain que o facao. Estou a chamar a
     * variavel de instancia
     */

    public void addTreasureToSlot(int prize) {

        if (prize > 0) {

            terreno[currentSlot] = new Slot(prize);
            currentSlot++;
        } else {

            terreno[currentSlot] = new Slot(NO_PRIZE);
            currentSlot++;

        }

    }

    public int getSlotStatusRemote(int slot) {

        return terreno[slot].getSlotStatus();
    }

    public int getAvailableSpace() {

        return availableSpace;
    }

    public int getTotalTreasure() {

        int sum = 0;
        for (int i = 0; i < availableSpace; i++) {
            if (terreno[i].getSlotStatus() == 1) {
                sum += terreno[i].getSlotStatus();

            } else {

            }

        }
        return sum;

    }

    public int dig(String identificacao, int jumpLength) {
        int i;
        int logstatus;
        int exists=0;
        for (i = 0,logstatus=0; i < MAX_PLAYERS; i++) {

            if (players[i].getPlayerName().equals(identificacao)) {
                exists++;
                if (players[i].getPlayerStatus() == PLAYING) {
                    if (players[i].getPlayerPos() + jumpLength-1 > 0 && terreno[players[i].getPlayerPos() + jumpLength-1].getSlotStatus() != Slot.EMPTY) {

                        players[i].movePlayer(players[i].getPlayerPos()+jumpLength-1);
                        players[i].addMerit(terreno[players[i].getPlayerPos()+jumpLength-1].getSlotTreasure());
                        terreno[players[i].getPlayerPos()+ jumpLength-1].addDigger(players[i]);
                        terreno[players[i].getPlayerPos() + jumpLength-1].setSlotTreasure(NO_PRIZE);
                        logstatus = 1;
                    } 
                    else if(players[i].getPlayerPos() + jumpLength-1 > 0 && terreno[players[i].getPlayerPos() + jumpLength-1].wasPreviouslyDugBy(players[i])) {

                        players[i].addMerit(-10);
                    } 
                    else if (players[i].getPlayerPos() + jumpLength-1 < FIRST_SLOT_OF_TERRAIN || players[i].getPlayerPos() + jumpLength-1 >= availableSpace) {

                        players[i].setPlayerStatus(KICKED);
                        logstatus = -1;
                    }
                    else if (jumpLength == 0) {

                        logstatus = 0;

                    } 
                }
                 else if (players[i].getPlayerStatus() == KICKED) {

                    logstatus = -2;
                } 
                else {

                }
            } 
            else {
            }

            if(exists==0){
                logstatus=-3;
            }

        }
        return logstatus;
    }

    public int getMeritRemote(String alias) {

        int value = 0;
        int exists=0;
        for (int i = 0; i < MAX_PLAYERS; i++) {

            if (players[i].getPlayerName().equals(alias)) {
                exists++;

                if (players[i].getPlayerStatus() == PLAYING) {

                    value = players[i].getPlayerMerit();
                }
                if (players[i].getPlayerStatus() == KICKED) {

                    value = -1;
                }
            }

            if(exists==0){

                value=-2;

            }

        }
        return value;
    }

    public int getPlayerPosRemote(String reference){
        int pos = 0;
        int exists=0;
        for (int i = 0; i < MAX_PLAYERS; i++) {

            if (players[i].getPlayerName().equals(reference)) {
                exists++;

                if (players[i].getPlayerStatus() == PLAYING) {

                    pos = players[i].getPlayerPos();
                }
                if (players[i].getPlayerStatus() == KICKED) {

                    pos = -1;
                }
            }
            else if(exists==0){

                pos=-2;
            }

        }
        return pos;
    }
}

/*Ok, Agora o proximo passo e fazer com que um slot "memorize" o arqueologo que o escavou para que, quando esse arqueologo voltar a tentar
escavar esse slot, que o slot o castigue por o tentar escavar.*/
