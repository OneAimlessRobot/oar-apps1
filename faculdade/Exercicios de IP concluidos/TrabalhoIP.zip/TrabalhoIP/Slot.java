public class Slot {
    /*Acrescentei isto para tornar o codigo um bocadinho mais claro.Nao e substancial mas ajuda (pelo menos a mim) */
    private static final int VALUABLE=1;
    public static final int EMPTY=0;
    private static final int SIZE=100;

    private int treasure, status,currentIndex;
    private Arqueologo[] whoDugMe;

    public Slot(int value){
        if(treasure>0){

            status=VALUABLE;
            treasure=value;
            whoDugMe=new Arqueologo[SIZE];



        }
        else{

            status=EMPTY;
            value=0;
        }
    }

    public void addDigger(Arqueologo jose){

        whoDugMe[currentIndex]=jose;
        currentIndex++;





    }

    public boolean wasPreviouslyDugBy(Arqueologo isabel){
        boolean result=false;

        for(int i=0;i<currentIndex;i++){

            if(whoDugMe[i].equals(isabel)){

                result=true;
            }
            else{

            }
        }
        return result;
    }

    public void setSlotStatus(int newstatus){

        this.status=newstatus;

    }

    public int getSlotStatus(){
        return this.status;
    }
    public int getSlotTreasure(){
        return this.treasure;
    }
    public void setSlotTreasure(int newtreasure){

        this.treasure=newtreasure;
    }

    
}
