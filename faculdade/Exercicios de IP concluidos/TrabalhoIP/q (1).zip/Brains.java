public class Brains {

    private static final int MAX_PLAYERS = 2;
    private static final int PENALTY_CONSTANT = 10;
    private static final int STARTING_MERIT = 0;
    private static final int STARTING_POINT = 0;

    private static Arqueologo[] playersList = new Arqueologo[MAX_PLAYERS];
    private int currentSlot;
    private int availableSpace;
    private Slot[] terreno;

    /*
     * Esta é a classe com a qual a main vai comunicar. Só e somente com esta. E
     * esta comunica com o resto.
     */

    public Brains(String nome1, String nome2, int terrainSize) {
        currentSlot=0;
        playersList[0] = new Arqueologo(nome1, STARTING_MERIT, STARTING_POINT);
        playersList[1] = new Arqueologo(nome2, STARTING_MERIT, STARTING_POINT);
        availableSpace = terrainSize + 1;
        /*Um dos membros do vetor (o primeiro) vai ser um slot especial: vai ser o ponto de partida do jogo. Avanca-se logo um slot para a frente para que nao sejam acrescentados tesouros ao primeiro slot */
        terreno = new Slot[availableSpace];
        terreno[currentSlot] = new Slot(0);
        currentSlot++;

    }
    /* Este metodo e de teste*/

    public String getNameRemote(int target) {

        return playersList[target - 1].getPlayerName();

    }
    /*Aqui, inicializamos o array de talhoes(slots) com valores de tesouro com o scanner da main. Esta projetado para os talhoes serem inicializados um de cada vez*/

    public void addTreasureToSlot(int prize) {

        if (prize > 0) {

            terreno[currentSlot] = new Slot(prize);
            currentSlot++;
        } else {

            terreno[currentSlot] = new Slot(0);
            currentSlot++;

        }

    }
    
    /**/

    public int getSlotStatusRemote(int slot) {

        return terreno[slot].getSlotStatus();
    }

    public int getAvailableSpace() {

        return this.availableSpace;
    }

    public int getSlotTreasureRemote(int slot) {
        return terreno[slot].getSlotTreasure();

    }
/*Metodo de verificacao usado pelo commando riqueza*/
    public int getTotalTreasure() {

        int sum = 0;
        for (int i = 0; i < availableSpace; i++) {
            if (terreno[i].getSlotStatus() == 1) {
                sum += terreno[i].getSlotTreasure();

            } else {

            }

        }
        return sum;

    }
    /*Este metodo e o mais complexo mas tambem o mais importante, pois e o que constitui a mecanica principal do programa que sao os saltos dos arqueologos e as consequecias aquando a sua aterragem*/

    public int dig(String identificacao, int jumpLength) {
        int i;
        int logstatus=-2313;
        int exists=0;
        int heavyAsARock=0;

        

        if (jumpLength == 0) {

            heavyAsARock++;
        } 
        else
        {
        for (i = 0, logstatus = 313232;i < MAX_PLAYERS; i++) {
            if(identificacao.equals(playersList[i].getPlayerName())){
                exists++;
                if (!playersList[i].isKicked()) {
                    if (jumpIsWithinBounds(playersList[i], jumpLength)) {
                            playersList[i].movePlayer(jumpLength);
                            if (!terreno[playersList[i].getPlayerPos()].wasPreviouslyDug()) {
                                collectPrize(playersList[i], terreno[playersList[i].getPlayerPos()]);
                            } 
                            else {
                                applyPenalty(playersList[i], terreno[playersList[i].getPlayerPos()]);
                            }
                        }
                    else {

                        playersList[i].kickPlayer();
                        logstatus = -1;
                    }
                } else {

                    logstatus = -2;
                }
            }
        }
        }
        
        if(exists==0){
            logstatus=-3;
        }
        if(heavyAsARock>0){
        	logstatus=0;
        }
        return logstatus;
    }
    
    /*Este metodo e usado pelo comando merito para revelar o progresso do arqueologo de nome "alias"*/

    public int getMeritRemote(String alias) {
        int value = 0;
        int exists=0;
        for (int i = 0;i < MAX_PLAYERS; i++) {
            if(alias.equals(playersList[i].getPlayerName())){
                exists++;
                if (!playersList[i].isKicked()) {
                    value = playersList[i].getPlayerMerit();
                } else {
                    value = -1;
                }
            }
        }
        if(exists==0){
            value=-3;
        }
        return value;
    }

    public int countKickedPlayers() {
        int sum = 0;
        for (int i = 0; i < MAX_PLAYERS; i++) {

            if (playersList[i].isKicked()) {
                sum++;
            } else {

            }
        }
        return sum;
    }
    /*Para testar*/

    public int getPlayerPosRemote(String reference) {
        int pos = 0;
        int exists=0;
        for (int i = 0;i < MAX_PLAYERS; i++) {
            if(reference.equals(playersList[i].getPlayerName())){
                exists++;
                if (!playersList[i].isKicked()) {
                    pos = playersList[i].getPlayerPos();
                } else {
                    pos = -1;
                }
            }
        }
        if(exists==0){
            pos=-3;
        }
        return pos;
    }

    public boolean jumpIsWithinBounds(Arqueologo jose, int dist) {

        return jose.getPlayerPos() + dist > STARTING_POINT && jose.getPlayerPos() + dist < this.getAvailableSpace();
    }
    /*
     * Este metodo roda sempre 2. Why? No ***ing idea... Pelo menos ja sei que salta
     * para os slots certos. UPDATE!!! NAO E DESTE METODO. E DO METODO DIG!!!!
     */

    public void collectPrize(Arqueologo maria, Slot hole) {
        maria.addMerit(hole.getSlotTreasure());
        hole.removeTreasure();
        hole.setToDug();
        hole.addPenaltyFactor();

    }
   
    /*Vai aplicar a penalizacao para quem tentar escavar talhoes que ja foram escavados*/

    public void applyPenalty(Arqueologo eva, Slot covaDaIria) {

            eva.addMerit(-1*PENALTY_CONSTANT * covaDaIria.getPenaltyFactor());
            covaDaIria.addPenaltyFactor();
        

    }
    
    /*Metodo que comunica com o talhao e retira dele o fator(^^^^^^) para a penalizacao*/


    public int getPenaltyFactorRemote(int i) {

        return terreno[i].getPenaltyFactor();
    }
    public int getMaxPlayers(){
        return MAX_PLAYERS;
    }
}

/*
 * Ok, Agora o proximo passo e fazer com que um slot "memorize" o arqueologo que
 * o escavou para que, quando esse arqueologo voltar a tentar escavar esse slot,
 * que o slot o castigue por o tentar escavar. Todos os talhoes funcionam de
 * forma igual.
 */
