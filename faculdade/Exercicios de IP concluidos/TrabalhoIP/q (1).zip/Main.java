import java.util.Scanner;

public class Main {

    private static final int NO_TREASURE = 0;
    private static final String TREASURE_SONAR = "riqueza";
    private static final String TERRAIN_SONAR = "terreno";
    private static final String JUMP = "escavacao";
    private static final String INVALID_CMD = "falhou";
    private static final String EXIT = "sair";
    private static final String GET_MERIT = "merito";
    /*private static final String GET_POS = "posicao";*/
    private static final String PLAYER_KICKED_ANNOUNCEMENT = "perdeu a licenca de escavacao";
    private static final String PLAYER_KICKED_EXEPTION = "Arqueologo desclassificado";
    private static final String INVALID_JUMP = "Salto invalido";
    private static final String NO_SUCH_PLAYER = "Arqueologo inexistente";
    private static final String BOTH_KICKED = "Correu mal! Foram ambos desclassificados.";
    private static final String TREASURE_REMAINING = "Ainda havia tesouros por descobrir...";
    private static final String TREASURE_IS_GONE = "Todos os tesouros foram descobertos!";

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        String exitCheck;
        String nome1 = in.nextLine();

        String nome2=in.nextLine();
        int size = in.nextInt();

        Brains sys = new Brains(nome1.trim(), nome2.trim(), size);

        for (int i = 0; i < size; i++) {
            int a = in.nextInt();
            sys.addTreasureToSlot(a);
        }
        
        /*Ok, isto tem um problema: se um comando for invalido e tiver varios parametros que o sucedem na input, todos os argumentos, alem da input, vao contar como comandos. em vez de so imprimir "comando invalido" uma vez, imprime uma vez por cada parametro que foi escrito, se nenhum deles por si so corresponder a um comando*/
        do {
       
        String option=in.next();
            exitCheck = menu(sys,option,in);
            if(exitCheck.equals(INVALID_CMD)){
            	System.out.printf("Comando invalido\n");
            }
            else{
            	
            }

        } while (!exitCheck.equals(EXIT));
        in.close();
    }

    private static String menu(Brains sysaux,String option,Scanner in) {
        String state = "";
       
        if (option.equals(TERRAIN_SONAR)) {

            printTerrainStatus(sysaux);

        } else if (option.equals(TREASURE_SONAR)) {

            System.out.printf("Riqueza enterrada: %d\n", sysaux.getTotalTreasure());

        } else if (option.equals(JUMP)) {
            int distance = in.nextInt();
            String Nome=in.nextLine();
            int log = sysaux.dig(Nome.trim(), distance);
            
            if (log == 0) {
                System.out.printf("%s\n", INVALID_JUMP);
            } else if (log == -1) {
                System.out.printf("%s %s\n",Nome.trim(), PLAYER_KICKED_ANNOUNCEMENT);
            } else if (log == -2) {
                System.out.printf("%s\n", PLAYER_KICKED_EXEPTION);
            } else if (log == -3) {
                System.out.printf("%s\n", NO_SUCH_PLAYER);
            } else {

            }
        } else if (option.equals(EXIT)) {

            if (sysaux.countKickedPlayers() < 2) {
                if (sysaux.getTotalTreasure() == 0) {
                    System.out.printf("%s\n", TREASURE_IS_GONE);

                } else {
                    System.out.printf("%s\n", TREASURE_REMAINING);
                }
            } else {

                System.out.printf("%s\n", BOTH_KICKED);

            }

            state = EXIT;

        } else if (option.equals(GET_MERIT)) {
        String Nome=in.nextLine();
            int merit = sysaux.getMeritRemote(Nome.trim());
            if (merit == -3) {
                System.out.printf("%s\n", NO_SUCH_PLAYER);
            } else if (merit == -1) {
                System.out.printf("%s\n", PLAYER_KICKED_EXEPTION);
            } else {
                System.out.printf("Merito de %s: %d\n", Nome.trim(), merit);
            }

        }

        else {
            state=INVALID_CMD;
            in.nextLine();
        }
        return state;
    }

    private static void printTerrainStatus(Brains sys) {

        for (int i = 1; i < sys.getAvailableSpace(); i++) {

            if (sys.getSlotStatusRemote(i) == NO_TREASURE) {
                System.out.printf("-");
            } else {

                System.out.printf("*");
            }
        }
        System.out.printf("\n");

    }

    /*
     * private static void printmenu() {
     *
     * System.out.printf(
     * "Commandos:\nriqueza - Ver quanta riqueza há ainda por descobrir\nterreno - Fazer um raio x do terreno\nescavacao - Forcar um arqueologo a fazer uma escavacao\nmerito - ver o merito atual de um arqueologo\nposicao - ver a posicao atual de um arqueologo\nsair - Sair\n"
     * ); }
     */

}
/*Codigo nao essencial que eu resolvi deixar porque sim. isto seria um comando posicao para indicar a posicao de um arqueologo*/

/* else if (option.equals(GET_POS)) {
String Nome=in.nextLine();
    int position = sysaux.getPlayerPosRemote(Nome.trim());
    if (position < 0) {
        if (position == -3) {
            System.out.printf("%s\n", NO_SUCH_PLAYER);
        } else {
            System.out.printf("%s\n", PLAYER_KICKED_EXEPTION);
        }
    } else {
        System.out.printf("Posicao de%s: %d\n", Nome, position);
    }
}*/

/* E isto seria um sistema para implementar no metodo principal que iria triar nome repetidos
do {
    nome2 = in.nextLine();
    if (nome2.equals(nome1)) {
        System.out.printf("Escolhe um nome diferente do primeiro\n");
    }
} while (nome2.equals(nome1));*/