#include "ProjectileIterator.hpp"
#include <iostream>

using namespace std;
/*
class Gun{
private:

Projectile **ammo;
Projectile **fired;
int capacity;
int projectSpeed;
int gunX;
int gunY;
int caliber;
int remaining;
int currentSlot;
int ammountFired;

public:

Gun(int capacity,int projectSpeed,int gunX,int gunY,int caliber){

    this->capacity=capacity;
    this->projectSpeed=projectSpeed;
    this->gunX=gunX;
    this->gunY=gunY;
    this->caliber=caliber;
    this->remaining=this->capacity;
    this->currentSlot=0;
    this->ammountFired=this->currentSlot;

    this->ammo=(Projectile**)malloc(sizeof(Projectile*)*this->capacity);
    this->fired=(Projectile**)malloc(sizeof(Projectile*));

    for(int i=0;i<this->capacity;i++){

        ammo[i]=new Projectile(gunX,gunY,projectSpeed,caliber,gunX,gunX);


    }
}
void growCluster(){


    Projectile **aux=(Projectile**)malloc(sizeof(Projectile*));

    
    for(int i=0;i<ammountFired+1;i++){


        aux[i]=new Projectile(1,1,1,1,1,1);
    }


    for(int i=0;i<ammountFired;i++){

        Projectile::projCopy(fired[i],(*(aux+i)));
    }
    for(int i=0;i<ammountFired;i++){

        delete(this->fired[i]);
        
    }
    ammountFired++;
    this->fired=aux;


}

void shrinkReserve(){


    if(this->remaining>0){
    Projectile **aux=(Projectile**)malloc(sizeof(Projectile*));

    for(int i=0;i<this->remaining-1;i++){

        (*(aux+i))=new Projectile(1,1,1,1,1,1);
    }

    for(int i=0;i<this->remaining-1;i++){
        cout<<1<<endl;

        Projectile::projCopy(this->ammo[i+1],this->ammo[i]);
    }

        cout<<2<<endl;
    for(int i=0;i<this->remaining-1;i++){

        Projectile::projCopy(this->ammo[i],(*(aux+i)));
    }

        cout<<3<<endl;

    for(int i=0;i<this->remaining-1;i++){

        delete(this->ammo[i]);
        
    }

    this->remaining--;
    this->ammo=aux;
    }


}

    void fireGun(SDL_Renderer*someRend,int xEnd,int yEnd){


        if(remaining>0){

            Projectile::projCopy(ammo[currentSlot],fired[currentSlot]);

            fired[currentSlot]->setTarget(xEnd,yEnd);
            this->currentSlot++;

        growCluster();
        shrinkReserve();
        }


    }


    void updateProjectiles(SDL_Renderer *someRend)
    {

        for(int i=0;i<ammountFired;i++){

            fired[i]->updateStillProjectile(someRend);


        }
    }
    void updateProjectilePositions()
    {

        for(int i=0;i<ammountFired;i++){


            fired[i]->updateMovingProjectile(gunX,gunY);


        }
    }
    void updateGunPos(int xOrigin, int yOrigin)
    {

        this->gunX = xOrigin;
        this->gunY = yOrigin;
    }
    int getXpos(){
        return gunX;
    }
    int getYpos(){
        return gunY;
    }

    ProjectileIterator* renderingIterator(){

        return new ProjectileIterator(fired,ammountFired);

    }

void destroyGun(){
    
}

};
*/