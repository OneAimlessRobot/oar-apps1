#include "entities.hpp"
#include "Player.hpp"
#include "audio.c"
#include <SDL2/SDL_image.h>


#define WIDTH 1000
#define HEIGHT 500

int musicOn;


void tocarmusica(void)
{
    if (musicOn == 0)
    {
        initAudio();
        FILE *ficheiro2 = fopen("musica.wav", "rb");
        playMusic("musica.wav", SDL_MIX_MAXVOLUME);
        SDL_Delay(100);

        musicOn = 1;
    }
    else if (musicOn == 1)
    {
        printf("A música já está a tocar\n");
    }
}
void pararmusica(void)
{

    if (musicOn == 1)
    {

        musicOn = 0;
        endAudio();
    }
    else if (musicOn == 0)
    {

        printf("A música já parou\n");
    }
}


int main()
{

    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(IMG_INIT_PNG);
    int step = 10, mousex, mousey,ammo,bulletCreated=0;

    cin >> ammo;

    SDL_Window *window = NULL;
    SDL_Renderer*rend=NULL;
    SDL_CreateWindowAndRenderer(WIDTH,HEIGHT,0,&window,&rend);
    SDL_Texture*texture=SDL_CreateTexture(rend,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,WIDTH,HEIGHT);
    Player *player = new Player(0, 0, 30);
    Projectile *bullet = new Projectile(player->getPlayerX(),player->getPlayerY(), 4,10);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear"); 
    SDL_RenderSetLogicalSize(rend,WIDTH*2,HEIGHT*2);

    const Uint8 *KEYBOARD = SDL_GetKeyboardState(NULL);




    bool running = true;
    SDL_Event event;


    while (running)
    {
        if(!bullet->isMoving()){
        bullet->updateLaunchSite(player->getPlayerX(),player->getPlayerY());
        }


        while (SDL_PollEvent(&event))
        {

            if (event.type == SDL_MOUSEBUTTONDOWN)
            {

                if (event.button.button == SDL_BUTTON_LEFT)
                {
                    
                    bullet->giveProjectileAPurposeInLife(2000*cos(atan2((mousey) - player->getPlayerY(), (mousex) - player->getPlayerX())),2000*sin(atan2((mousey) - player->getPlayerY(), (mousex) - player->getPlayerX())));
                }
            }
            if (event.type == SDL_KEYDOWN)
            {

                if (KEYBOARD[SDL_SCANCODE_S])
                {
                    player->movePlayerY(step);
                }

                if (KEYBOARD[SDL_SCANCODE_W])
                {

                    player->movePlayerY(-step);
                }

                if (KEYBOARD[SDL_SCANCODE_A])
                {

                    player->movePlayerX(-step);
                }
                if (KEYBOARD[SDL_SCANCODE_D])
                {

                    player->movePlayerX(step);
                }

                if (KEYBOARD[SDL_SCANCODE_S] && KEYBOARD[SDL_SCANCODE_A])
                {

                    player->movePlayerY(step);
                    player->movePlayerX(-step);
                }
                if (KEYBOARD[SDL_SCANCODE_W] && KEYBOARD[SDL_SCANCODE_A])
                {

                    player->movePlayerY(-step);
                    player->movePlayerX(-step);
                }
                if (KEYBOARD[SDL_SCANCODE_S] && KEYBOARD[SDL_SCANCODE_D])
                {

                    player->movePlayerY(step);
                    player->movePlayerX(step);
                }
                if (KEYBOARD[SDL_SCANCODE_W] && KEYBOARD[SDL_SCANCODE_A])
                {

                    player->movePlayerY(-step);
                    player->movePlayerX(-step);
                }

                if (KEYBOARD[SDL_SCANCODE_SPACE])
                {

                    cout <<"Posiçao do Player: "<< player->getPlayerX() << " , " << player->getPlayerY() << endl;
                    cout <<"Posiçao do projetil: "<< bullet->getXpos() << " , " << bullet->getYpos() << endl;
                    cout <<"Posiçao do alvo: "<< bullet->getTarget()->x << " , " << bullet->getTarget()->y << endl;
                }
                if (KEYBOARD[SDL_SCANCODE_ESCAPE])
                {

                    running = false;
                }
                if (KEYBOARD[SDL_SCANCODE_UP])
                {
                    bullet->speedUp(1);
                    cout<<"Velocidade do projetil: "<<bullet->getSpeed()<<endl;
                }

                if (KEYBOARD[SDL_SCANCODE_DOWN])
                {
                    bullet->speedDown(1);
                    cout<<"Velocidade do projetil: "<<bullet->getSpeed()<<endl;
                }

                if (KEYBOARD[SDL_SCANCODE_LEFT])
                {
                    player->shrinkPlayer(1);
                }

                if (KEYBOARD[SDL_SCANCODE_RIGHT])
                {
                    player->growPlayer(1);
                }

                if (KEYBOARD[SDL_SCANCODE_M])
                {
                    if(musicOn==0){
                    tocarmusica();
                    }
                    else{
                        pararmusica();
                    }
                }
            }
            if (event.type == SDL_QUIT)
            {

                running = false;
            }
            
        }
        SDL_SetRenderDrawColor(rend,0,0,0,255);
        SDL_SetRenderTarget(rend,texture);
        SDL_RenderClear(rend);
        player->keepPlayerVisible(rend,&mousex, &mousey);
        bullet->updateMovingProjectile(player->getPlayerX(),player->getPlayerY());
        bullet->updateStillProjectile(rend);

        if(!bullet->hasColisionWithBox(&SDL_GetWindowSurface(window)->clip_rect)){

            
        bullet->destroyProjectile();

            bullet->updateLaunchSite(player->getPlayerX(),player->getPlayerY());

        }
        SDL_SetRenderTarget(rend,NULL);
        SDL_RenderCopy(rend,texture,NULL,NULL);
        SDL_RenderPresent(rend);
    }
    player->destroyPlayer();
    delete(bullet);
    delete(player);
    SDL_DestroyRenderer(rend);
    SDL_DestroyWindow(window);

    IMG_Quit();
    SDL_Quit();
}